
import java.util.ArrayList;
import java.util.List;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Laura
 */
// Clase Cliente
class Cliente {
    private final String nombre;
    private final List<Producto> carrito;

    public Cliente(String nombre) {
        this.nombre = nombre;
        this.carrito = new ArrayList<>();
    }

    public String getNombre() {
        return nombre;
    }

    public List<Producto> getCarrito() {
        return carrito;
    }

    public void agregarProducto(Producto producto) {
        carrito.add(producto);
    }
}

