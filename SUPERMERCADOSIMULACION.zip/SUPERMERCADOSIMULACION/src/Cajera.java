/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Laura
 */
// Clase Cajera que implementa Runnable
class Cajera implements Runnable {
    private final Cliente cliente;

    public Cajera(Cliente cliente) {
        this.cliente = cliente;
    }

    @Override
    public void run() {
        System.out.println("La cajera comienza a atender al cliente " + cliente.getNombre());
        double total = 0;
        for (Producto producto : cliente.getCarrito()) {
            procesarProducto(producto);
            total += producto.getPrecio();
        }
        System.out.println("La cajera ha terminado de atender al cliente " + cliente.getNombre() + ". Total: $" + total);
    }

    private void procesarProducto(Producto producto) {
        System.out.println("Procesando producto: " + producto.getNombre() + " | Precio: $" + producto.getPrecio());
        try {
            Thread.sleep(1000); // Simula el tiempo que tarda en pasar un producto por el escáner
        } catch (InterruptedException e) {
            System.out.println("El proceso fue interrumpido");
        }
    }
}

