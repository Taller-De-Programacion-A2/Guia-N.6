/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author Laura
 */
// Clase principal para simular el supermercado
public class SupermercadoSimulacion {
    public static void main(String[] args) {
        // Crear productos
        Producto p1 = new Producto("Pan", 1.00);
        Producto p2 = new Producto("Leche", 1.50);
        Producto p3 = new Producto("Queso", 3.00);
        Producto p4 = new Producto("Huevos", 2.50);

        // Crear clientes y agregar productos a su carrito
        Cliente cliente1 = new Cliente("Lucas");
        cliente1.agregarProducto(p1);
        cliente1.agregarProducto(p2);

        Cliente cliente2 = new Cliente("Andrea");
        cliente2.agregarProducto(p3);
        cliente2.agregarProducto(p4);

        // Crear hilos para simular que la cajera atiende a los clientes
        Cajera cajera1 = new Cajera(cliente1);
        Cajera cajera2 = new Cajera(cliente2);

        Thread hiloCajera1 = new Thread(cajera1);
        Thread hiloCajera2 = new Thread(cajera2);

        // Iniciar los hilos para atender a los clientes
        hiloCajera1.start();
        try {
            hiloCajera1.join(); // Asegura que el primer cliente sea atendido antes de que empiece el siguiente
        } catch (InterruptedException e) {
        }

        hiloCajera2.start();
        try {
            hiloCajera2.join(); // Espera a que el segundo cliente termine
        } catch (InterruptedException e) {
        }
    }
}
