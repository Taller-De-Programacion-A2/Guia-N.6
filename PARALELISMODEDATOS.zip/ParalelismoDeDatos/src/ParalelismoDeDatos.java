/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author Laura
 */
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ForkJoinPool;
import java.util.stream.Collectors;

public class ParalelismoDeDatos {
    public static void main(String[] args) {
        ForkJoinPool forkJoinPool = new ForkJoinPool();

        // Lista de datos grandes
        List<Integer> datos = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);

        // Paralelismo para calcular el cuadrado de los números
        List<Integer> resultado = forkJoinPool.submit(() ->
            datos.parallelStream()
                 .map(x -> x * x)
                 .collect(Collectors.toList())
        ).join();

        System.out.println("Cuadrados: " + resultado);
    }
}
