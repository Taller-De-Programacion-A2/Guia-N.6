package productorconsumidor;

import java.util.Random;

//Espacio creado para conectar los hilos
class Buffer {

    private int numero;
    private boolean disponible = false;

    // El productor coloca un número en el buffer
    public synchronized void colocarNumero(int numero) {
        while (disponible) {
            try {
                wait(); // Si ya hay un número, espera
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        this.numero = numero;
        disponible = true;
        notify(); // Notifica al consumidor que hay un número disponible
    }

    // El consumidor toma un número del buffer
    public synchronized int obtenerNumero() {
        while (!disponible) {
            try {
                wait(); // Si no hay un número, espera
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        disponible = false;
        notify(); // Notifica al productor que el número fue consumido
        return numero;
    }
}

//Generar el primer hilo extendiendo el Thread
class Productor extends Thread {

    private Buffer buffer; //Llamo la clase Buffer

    public Productor(Buffer buffer) { //La inicializo dentro de la clase de Productor
        this.buffer = buffer;
    }

    public void run() {
        Random rand = new Random();
        while (true) {
            int numero = rand.nextInt(100) + 1;
            System.out.println("Productor genera: " + numero);
            buffer.colocarNumero(numero); //llamo al metodo
            try {
                Thread.sleep(1000); // Simula el tiempo que toma generar un número
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}

//Generar el segundo hilo extendiendo el Thread
class Consumidor extends Thread {

    private Buffer buffer;

    public Consumidor(Buffer buffer) {
        this.buffer = buffer;
    }

    public void run() {
        while (true) {
            int numero = buffer.obtenerNumero();//llama el metodo de obtencion pues es consumidor
            System.out.println("Consumidor procesa: " + (numero * 2));
            try {
                Thread.sleep(1000); // Simula el tiempo de procesamiento
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}

public class ProductorConsumidor {

    public static void main(String[] args) {
        Buffer buffer = new Buffer();
        Productor productor = new Productor(buffer);
        Consumidor consumidor = new Consumidor(buffer);

        productor.start();//Llamada de inicio
        consumidor.start(); //Llamada de inicio
    }
}
