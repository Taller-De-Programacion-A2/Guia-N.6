/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author Laura
 */
// Clase principal para ejecutar el programa
public class CallCenterSimulacion {
    public static void main(String[] args) {
        Persona persona1 = new Persona("Adrian");
        Persona persona2 = new Persona("Laura");

        Telefono telefono1 = new Telefono("3004635789");
        Telefono telefono2 = new Telefono("3133840498");

        // Simular llamadas
        persona1.realizarLlamada(telefono1);
        persona2.realizarLlamada(telefono2);
    }
}

