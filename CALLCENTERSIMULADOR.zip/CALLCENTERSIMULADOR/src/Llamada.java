/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Laura
 */

// Clase Llamada que implementa Runnable
public class Llamada implements Runnable {
    private final Persona persona;
    private final Telefono telefono;

    public Llamada(Persona persona, Telefono telefono) {
        this.persona = persona;
        this.telefono = telefono;
    }

    @Override
    public void run() {
        System.out.println(persona.getNombre() + " esta realizando una llamada usando el telefono " + telefono.getNumero());
        try {
            Thread.sleep(4000); // Simula el tiempo de la llamada
        } catch (InterruptedException e) {
            System.out.println("La llamada fue interrumpida");
        }
        System.out.println(persona.getNombre() + " ha finalizado la llamada.");
    }
}

