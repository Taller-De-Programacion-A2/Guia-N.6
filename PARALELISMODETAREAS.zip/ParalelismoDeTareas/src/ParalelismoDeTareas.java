/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author Laura
 */

public class ParalelismoDeTareas {
    public static void main(String[] args) throws InterruptedException {
        // Datos a procesar
        int[] datos = {1, 2, 3, 4, 5};

        // Crear el primer hilo para calcular los cuadrados
        Thread hiloCuadrados = new Thread(() -> {
            for (int num : datos) {
                System.out.println("Cuadrado de " + num + ": " + (num * num));
            }
        });

        // Crear el segundo hilo para calcular los cubos
        Thread hiloCubos = new Thread(() -> {
            for (int num : datos) {
                System.out.println("Cubo de " + num + ": " + (num * num * num));
            }
        });

        // Iniciar ambos hilos
        hiloCuadrados.start();
        hiloCubos.start();

        // Esperar que ambos hilos terminen
        hiloCuadrados.join();
        hiloCubos.join();
    }
}

